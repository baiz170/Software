# Project memory

## Product intent & audience

- Educational assignment ("Practice #12") comparing two implementations of an availability/booking checker: a code-based React app and an Appsmith low-code app.
- Audience is an instructor/grader requiring documented evidence: security review, screenshots, and consistent Markdown documentation across three files.

## Brand personality & voice

- Documentation tone: precise, audit-style, non-claiming — never states a check was performed unless actually done.
- Explicit "Not measured" / "pending" labels used where evidence is unavailable.

## Visual design & UX direction

- Code-based UI renders availability results (Available / Unavailable overlap) for desktop and mobile; likely uses Tailwind for layout and Lucide React for icons.
- Appsmith counterpart mirrors the same availability logic via in-platform JavaScript.
- Screenshots required for: code-based desktop (Available + Unavailable), mobile, and Appsmith builder canvas + result views.

## Decisions, constraints & rationale

- **No application code modifications during audit** — only Markdown docs updated.
- Three documentation files must stay consistent: `PRACTICE_12_REPORT.md`, `PRACTICE_12_TESTS.md`, `APPSMITH_IMPLEMENTATION.md`.
- Test file: `src/lib/practice12.test.ts` (part of submission).
- Core logic lives in `src/lib/availability.ts` (input validation verified here).
- Supabase dependency is present but unused in the code-based implementation; no secrets or Supabase imports found.
- Status set to **NOT READY** — missing: complete Appsmith security/settings review, all required screenshots, confirmed submission paths for supplied Appsmith images.
- Build/fix timings marked "Not measured" — no reliable records exist.
- Repository contains no image files; three Appsmith screenshots were supplied as external attachments only (filenames: `Screenshot_2026-11-24_at_15.22.58.png`, `...15.23.10.png`, `...15.24.40.png`).

## Open questions & assumptions

- Appsmith security settings (sharing, permissions, version, access control) remain unverified — need platform access.
- Whether an "explanation-expanded" screenshot is required is unconfirmed.
- Submission/storage locations for the three supplied Appsmith screenshots are unknown.
- Missing code-based screenshots (desktop Available, desktop Unavailable, mobile) still need to be captured.